const mongoose = require("mongoose");

// This function connects our app to MongoDB.
// We call it once when the server starts (see server.js).
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    // If we can't connect to the DB, there's no point running the server
    process.exit(1);
  }
};

module.exports = connectDB;
