const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    // Chats happen in the context of a project (per the spec: "once accepted, users can chat")
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true,
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    content: {
      type: String,
      required: true,
      trim: true,
    },
    isRead: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Speeds up fetching "all messages between these two people on this project"
messageSchema.index({ project: 1, sender: 1, recipient: 1 });

module.exports = mongoose.model("Message", messageSchema);
