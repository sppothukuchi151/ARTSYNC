const mongoose = require("mongoose");

const requestSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
      required: true,
    },
    applicant: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    message: {
      type: String, // e.g. "I have experience in Adobe Illustrator and would love to help"
      default: "",
    },
    status: {
      type: String,
      enum: ["pending", "accepted", "rejected"],
      default: "pending",
    },
  },
  {
    timestamps: true,
  }
);

// Prevents the same user from sending multiple requests to the same project
requestSchema.index({ project: 1, applicant: 1 }, { unique: true });

module.exports = mongoose.model("Request", requestSchema);
