const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema(
  {
    // Links this project to the user who created it.
    // "ref: User" lets us later fetch the full owner details with .populate()
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    title: {
      type: String,
      required: [true, "Project name is required"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Description is required"],
    },
    requiredSkills: {
      type: [String], // e.g. ["React", "Figma"]
      default: [],
    },
    deadline: {
      type: Date,
    },
    collaboratorsNeeded: {
      type: Number,
      default: 1,
      min: 1,
    },
    category: {
      type: String,
      // Matches the artist types mentioned in your spec.
      // "Other" is a safe fallback for anything that doesn't fit.
      enum: [
        "Music",
        "Design",
        "Writing",
        "Photography",
        "Filmmaking",
        "Illustration",
        "Other",
      ],
      default: "Other",
    },
    status: {
      type: String,
      enum: ["open", "closed"],
      default: "open", // owners can mark a project "closed" once team is full
    },
  },
  {
    timestamps: true,
  }
);

// This makes text search (used in Step 6 - Browse & Search) fast and easy
projectSchema.index({ title: "text", description: "text" });

module.exports = mongoose.model("Project", projectSchema);
