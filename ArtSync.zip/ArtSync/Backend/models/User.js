const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

// This schema defines the shape of a "user" document in MongoDB.
const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true, // no two users can share an email
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: 6,
      // select: false means this field won't be returned in queries by default,
      // so we never accidentally send password hashes to the frontend.
      select: false,
    },
    bio: {
      type: String,
      default: "",
      maxlength: 500,
    },
    skills: {
      type: [String], // e.g. ["React", "UI Design", "Illustration"]
      default: [],
    },
    experience: {
      type: String,
      default: "",
    },
    portfolioLinks: {
      behance: { type: String, default: "" },
      github: { type: String, default: "" },
      instagram: { type: String, default: "" },
      website: { type: String, default: "" },
    },
    location: {
      type: String,
      default: "",
    },
    profilePicture: {
      type: String, // will store a URL to the image
      default: "",
    },
  },
  {
    timestamps: true, // automatically adds createdAt and updatedAt fields
  }
);

// This runs automatically right BEFORE a user is saved to the database.
// It hashes the plain-text password so we never store it in readable form.
userSchema.pre("save", async function (next) {
  // Only hash the password if it's new or has been changed
  if (!this.isModified("password")) {
    return next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Instance method to check a plain-text password against the stored hash.
// We'll use this during login: user.matchPassword(enteredPassword)
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model("User", userSchema);
