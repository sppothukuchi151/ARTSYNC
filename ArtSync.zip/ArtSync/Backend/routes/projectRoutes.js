const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createProject,
  getProjects,
  getProjectById,
  updateProject,
  deleteProject,
} = require("../controllers/projectController");

// POST /api/projects - create a project (must be logged in)
router.post("/", protect, createProject);

// GET /api/projects - browse all projects (public)
router.get("/", getProjects);

// GET /api/projects/:id - view one project's details (public)
router.get("/:id", getProjectById);

// PUT /api/projects/:id - edit a project (must be the owner)
router.put("/:id", protect, updateProject);

// DELETE /api/projects/:id - delete a project (must be the owner)
router.delete("/:id", protect, deleteProject);

module.exports = router;
