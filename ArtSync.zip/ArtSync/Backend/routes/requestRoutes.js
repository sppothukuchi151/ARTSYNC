const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  sendRequest,
  getRequestsForProject,
  getMyRequests,
  respondToRequest,
} = require("../controllers/requestController");

// POST /api/requests - send a "request to join" for a project
router.post("/", protect, sendRequest);

// GET /api/requests/my - see requests I've sent
router.get("/my", protect, getMyRequests);

// GET /api/requests/project/:projectId - see requests received on my project
router.get("/project/:projectId", protect, getRequestsForProject);

// PUT /api/requests/:id - accept or reject a request
router.put("/:id", protect, respondToRequest);

module.exports = router;
