const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { getMessages } = require("../controllers/messageController");

// GET /api/messages/:projectId/:otherUserId - load chat history
router.get("/:projectId/:otherUserId", protect, getMessages);

module.exports = router;
