const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  getMyNotifications,
  markAsRead,
  markAllAsRead,
} = require("../controllers/notificationController");

// GET /api/notifications - view all my notifications
router.get("/", protect, getMyNotifications);

// PUT /api/notifications/read-all - mark all as read
router.put("/read-all", protect, markAllAsRead);

// PUT /api/notifications/:id/read - mark one as read
router.put("/:id/read", protect, markAsRead);

module.exports = router;
