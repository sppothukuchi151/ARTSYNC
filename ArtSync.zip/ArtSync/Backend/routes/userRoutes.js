const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { getMyProfile, updateMyProfile, getUserById } = require("../controllers/userController");

// Order matters here: "/me" must come BEFORE "/:id",
// otherwise Express would think "me" is an :id value.

// GET /api/users/me - view my own profile (must be logged in)
router.get("/me", protect, getMyProfile);

// PUT /api/users/me - update my own profile (must be logged in)
router.put("/me", protect, updateMyProfile);

// GET /api/users/:id - view anyone's public profile (no login required)
router.get("/:id", getUserById);

module.exports = router;
