const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { saveProject, unsaveProject, getSavedProjects } = require("../controllers/savedController");

// GET /api/saved - view all my bookmarked projects
router.get("/", protect, getSavedProjects);

// POST /api/saved/:projectId - bookmark a project
router.post("/:projectId", protect, saveProject);

// DELETE /api/saved/:projectId - remove a bookmark
router.delete("/:projectId", protect, unsaveProject);

module.exports = router;
