const jwt = require("jsonwebtoken");
const User = require("../models/User");

// This middleware checks incoming requests for a valid JWT token.
// If valid, it attaches the logged-in user's info to req.user
// so later route handlers know who's making the request.
// We'll use this on routes like "create project" or "send request"
// that should only work for logged-in users.
const protect = async (req, res, next) => {
  let token;

  // Tokens are sent in the request header like: "Bearer eyJhbGciOi..."
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
    try {
      token = req.headers.authorization.split(" ")[1];

      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Attach the user (minus password) to the request object
      req.user = await User.findById(decoded.id).select("-password");

      return next(); // token valid - allow the request to continue
    } catch (error) {
      return res.status(401).json({ message: "Not authorized, invalid token" });
    }
  }

  if (!token) {
    return res.status(401).json({ message: "Not authorized, no token provided" });
  }
};

module.exports = { protect };
