const SavedProject = require("../models/SavedProject");
const Project = require("../models/Project");

// @route   POST /api/saved/:projectId
// @desc    Bookmark a project
// @access  Private
const saveProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    const saved = await SavedProject.create({
      user: req.user._id,
      project: req.params.projectId,
    });

    res.status(201).json(saved);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: "You already saved this project" });
    }
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   DELETE /api/saved/:projectId
// @desc    Remove a bookmark
// @access  Private
const unsaveProject = async (req, res) => {
  try {
    const result = await SavedProject.findOneAndDelete({
      user: req.user._id,
      project: req.params.projectId,
    });

    if (!result) {
      return res.status(404).json({ message: "Bookmark not found" });
    }

    res.json({ message: "Project removed from saved list" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/saved
// @desc    Get all projects I've bookmarked
// @access  Private
const getSavedProjects = async (req, res) => {
  try {
    const saved = await SavedProject.find({ user: req.user._id })
      .populate({
        path: "project",
        populate: { path: "owner", select: "name profilePicture" },
      })
      .sort({ createdAt: -1 });

    res.json(saved);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = { saveProject, unsaveProject, getSavedProjects };
