const User = require("../models/User");

// @route   GET /api/users/me
// @desc    Get the logged-in user's own full profile
// @access  Private (requires valid JWT token)
const getMyProfile = async (req, res) => {
  // req.user was already set by the "protect" middleware -
  // it looked up the user from the token before this function ran.
  res.json(req.user);
};

// @route   PUT /api/users/me
// @desc    Update the logged-in user's profile
// @access  Private
const updateMyProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Only update fields that were actually sent in the request body.
    // This means the frontend can send just one field (e.g. only "bio")
    // without needing to resend the entire profile every time.
    const { name, bio, skills, experience, portfolioLinks, location, profilePicture } = req.body;

    if (name !== undefined) user.name = name;
    if (bio !== undefined) user.bio = bio;
    if (skills !== undefined) user.skills = skills;
    if (experience !== undefined) user.experience = experience;
    if (location !== undefined) user.location = location;
    if (profilePicture !== undefined) user.profilePicture = profilePicture;

    // portfolioLinks is a nested object, so we merge it field by field
    // instead of overwriting the whole thing (in case only one link is sent)
    if (portfolioLinks !== undefined) {
      user.portfolioLinks = { ...user.portfolioLinks, ...portfolioLinks };
    }

    const updatedUser = await user.save();

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      bio: updatedUser.bio,
      skills: updatedUser.skills,
      experience: updatedUser.experience,
      portfolioLinks: updatedUser.portfolioLinks,
      location: updatedUser.location,
      profilePicture: updatedUser.profilePicture,
    });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/users/:id
// @desc    Get any user's public profile (e.g. viewing someone else's page)
// @access  Public
const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user);
  } catch (error) {
    // This catches invalid MongoDB IDs (e.g. someone typing a random string in the URL)
    res.status(400).json({ message: "Invalid user ID" });
  }
};

module.exports = { getMyProfile, updateMyProfile, getUserById };
