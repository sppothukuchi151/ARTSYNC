const Request = require("../models/Request");
const Project = require("../models/Project");
const Notification = require("../models/Notification");

// @route   POST /api/requests
// @desc    Send a request to join a project ("Request to Join" button)
// @access  Private
const sendRequest = async (req, res) => {
  try {
    const { projectId, message } = req.body;

    if (!projectId) {
      return res.status(400).json({ message: "projectId is required" });
    }

    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (project.owner.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: "You cannot request to join your own project" });
    }

    const request = await Request.create({
      project: projectId,
      applicant: req.user._id,
      message,
    });

    await Notification.create({
      recipient: project.owner,
      type: "new_request",
      message: `${req.user.name} wants to join your project "${project.title}"`,
      relatedProject: project._id,
      relatedRequest: request._id,
    });

    res.status(201).json(request);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: "You already requested to join this project" });
    }
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/requests/project/:projectId
// @desc    View all requests received for one of your projects
// @access  Private (only the project owner should see these)
const getRequestsForProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (project.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view these requests" });
    }

    const requests = await Request.find({ project: req.params.projectId })
      .populate("applicant", "name profilePicture skills bio")
      .sort({ createdAt: -1 });

    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/requests/my
// @desc    View all requests I've sent to other people's projects
// @access  Private
const getMyRequests = async (req, res) => {
  try {
    const requests = await Request.find({ applicant: req.user._id })
      .populate({
        path: "project",
        select: "title category status owner",
        populate: { path: "owner", select: "name" },
      })
      .sort({ createdAt: -1 });

    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   PUT /api/requests/:id
// @desc    Accept or reject a request ("Accept | Reject" buttons)
// @access  Private (only the project owner)
const respondToRequest = async (req, res) => {
  try {
    const { status } = req.body;

    if (!["accepted", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Status must be 'accepted' or 'rejected'" });
    }

    const request = await Request.findById(req.params.id).populate("project");

    if (!request) {
      return res.status(404).json({ message: "Request not found" });
    }

    if (request.project.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to respond to this request" });
    }

    request.status = status;
    await request.save();

    await Notification.create({
      recipient: request.applicant,
      type: status === "accepted" ? "request_accepted" : "request_rejected",
      message:
        status === "accepted"
          ? `Your request to join "${request.project.title}" was accepted!`
          : `Your request to join "${request.project.title}" was declined`,
      relatedProject: request.project._id,
      relatedRequest: request._id,
    });

    res.json(request);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = { sendRequest, getRequestsForProject, getMyRequests, respondToRequest };
