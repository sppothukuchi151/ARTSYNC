const Message = require("../models/Message");
const Request = require("../models/Request");

// @route   GET /api/messages/:projectId/:otherUserId
// @desc    Get the full chat history between me and another user, for one project
// @access  Private
const getMessages = async (req, res) => {
  try {
    const { projectId, otherUserId } = req.params;

    // Security check: only allow chatting if there's an ACCEPTED request
    // between these two users on this project (matches the spec: "Once
    // accepted, users can chat" - random strangers can't message each other)
    const acceptedRequest = await Request.findOne({
      project: projectId,
      status: "accepted",
      $or: [
        { applicant: req.user._id },
        { applicant: otherUserId },
      ],
    });

    if (!acceptedRequest) {
      return res.status(403).json({ message: "You can only chat after a request has been accepted" });
    }

    // Find every message between these two users on this project, either direction
    const messages = await Message.find({
      project: projectId,
      $or: [
        { sender: req.user._id, recipient: otherUserId },
        { sender: otherUserId, recipient: req.user._id },
      ],
    }).sort({ createdAt: 1 }); // oldest first, so chat reads top-to-bottom

    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = { getMessages };
