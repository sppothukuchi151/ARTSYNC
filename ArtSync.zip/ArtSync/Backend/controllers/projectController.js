const Project = require("../models/Project");

// @route   POST /api/projects
// @desc    Create a new project
// @access  Private (must be logged in)
const createProject = async (req, res) => {
  try {
    const { title, description, requiredSkills, deadline, collaboratorsNeeded, category } = req.body;

    if (!title || !description) {
      return res.status(400).json({ message: "Title and description are required" });
    }

    const project = await Project.create({
      owner: req.user._id, // comes from the "protect" middleware
      title,
      description,
      requiredSkills,
      deadline,
      collaboratorsNeeded,
      category,
    });

    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/projects
// @desc    Get all projects, with optional filtering by category and keyword search
// @access  Public
const getProjects = async (req, res) => {
  try {
    const { category, search } = req.query;

    // Build a MongoDB query object based on which filters were provided
    const query = {};

    if (category) {
      query.category = category;
    }

    if (search) {
      // $text uses the text index we defined on the Project model
      // (title + description) - matches whole words, case-insensitive
      query.$text = { $search: search };
    }

    const projects = await Project.find(query)
      .populate("owner", "name profilePicture")
      .sort({ createdAt: -1 });

    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   GET /api/projects/:id
// @desc    Get a single project's full details
// @access  Public
const getProjectById = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id).populate(
      "owner",
      "name profilePicture bio skills"
    );

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    res.json(project);
  } catch (error) {
    res.status(400).json({ message: "Invalid project ID" });
  }
};

// @route   PUT /api/projects/:id
// @desc    Update a project (only the owner can do this)
// @access  Private
const updateProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    // Security check: make sure the logged-in user actually owns this project
    if (project.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to edit this project" });
    }

    const { title, description, requiredSkills, deadline, collaboratorsNeeded, category, status } = req.body;

    if (title !== undefined) project.title = title;
    if (description !== undefined) project.description = description;
    if (requiredSkills !== undefined) project.requiredSkills = requiredSkills;
    if (deadline !== undefined) project.deadline = deadline;
    if (collaboratorsNeeded !== undefined) project.collaboratorsNeeded = collaboratorsNeeded;
    if (category !== undefined) project.category = category;
    if (status !== undefined) project.status = status;

    const updatedProject = await project.save();
    res.json(updatedProject);
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// @route   DELETE /api/projects/:id
// @desc    Delete a project (only the owner can do this)
// @access  Private
const deleteProject = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ message: "Project not found" });
    }

    if (project.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to delete this project" });
    }

    await project.deleteOne();
    res.json({ message: "Project deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

module.exports = {
  createProject,
  getProjects,
  getProjectById,
  updateProject,
  deleteProject,
};
