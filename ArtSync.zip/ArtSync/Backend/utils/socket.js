const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");
const Message = require("../models/Message");
const Notification = require("../models/Notification");

// This function sets up real-time chat. It's called once from server.js,
// passing in the raw HTTP server so Socket.IO can attach to it.
const initSocket = (httpServer) => {
  const io = new Server(httpServer, {
    cors: {
      origin: "*", // in production, restrict this to your real frontend URL
    },
  });

  // This middleware runs BEFORE a socket connection is accepted.
  // It checks the JWT token the frontend sends, so we know who's connecting -
  // same idea as the "protect" middleware, but for sockets instead of HTTP routes.
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) {
        return next(new Error("Not authorized, no token provided"));
      }
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id; // attach the user's ID to this socket connection
      next();
    } catch (error) {
      next(new Error("Not authorized, invalid token"));
    }
  });

  io.on("connection", (socket) => {
    console.log(`Socket connected: user ${socket.userId}`);

    // Each user joins a "room" named after their own user ID.
    // This lets us send them a message directly, without needing to track
    // which exact socket/tab/device they're using.
    socket.join(socket.userId);

    // Fires when the frontend calls socket.emit("sendMessage", {...})
    socket.on("sendMessage", async ({ projectId, recipientId, content }) => {
      try {
        if (!projectId || !recipientId || !content?.trim()) {
          return socket.emit("errorMessage", { message: "Missing required fields" });
        }

        // Save the message to the database so chat history persists
        const message = await Message.create({
          project: projectId,
          sender: socket.userId,
          recipient: recipientId,
          content: content.trim(),
        });

        // Send it instantly to the recipient, IF they're currently online
        io.to(recipientId).emit("receiveMessage", message);

        // Also echo it back to the sender, so their own chat window updates too
        socket.emit("receiveMessage", message);

        // Create a notification too, in case the recipient isn't online/watching chat
        await Notification.create({
          recipient: recipientId,
          type: "new_message",
          message: "You have a new message",
          relatedProject: projectId,
        });
      } catch (error) {
        socket.emit("errorMessage", { message: "Failed to send message", error: error.message });
      }
    });

    socket.on("disconnect", () => {
      console.log(`Socket disconnected: user ${socket.userId}`);
    });
  });

  return io;
};

module.exports = initSocket;
