const jwt = require("jsonwebtoken");

// Creates a signed JWT containing the user's ID.
// The frontend will store this token and send it with future requests
// to prove "I am this logged-in user" without sending the password again.
const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: "30d", // token stays valid for 30 days
  });
};

module.exports = generateToken;
