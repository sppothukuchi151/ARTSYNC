import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const navLinks = [
    { to: "/browse", label: "Browse" },
    { to: "/saved", label: "Saved" },
    { to: "/requests", label: "Requests" },
    { to: "/notifications", label: "Notifications" },
  ];

  return (
    <nav className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-violet/15">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/browse" className="font-display font-bold text-xl text-indigo">
          ArtSync
        </Link>

        <div className="hidden sm:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="text-sm font-medium text-ink/70 hover:text-primary hover:bg-lavender/40 rounded-lg px-3 py-2 transition-colors"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/projects/new"
            className="hidden sm:block bg-primary hover:bg-indigo transition-colors text-white text-sm font-medium rounded-lg px-4 py-2"
          >
            + New Project
          </Link>
          <Link to="/profile" className="text-sm font-medium text-ink/70 hover:text-primary transition-colors">
            {user?.name?.split(" ")[0]}
          </Link>
          <button
            onClick={handleLogout}
            className="text-sm font-medium text-ink/50 hover:text-red-600 transition-colors"
          >
            Log out
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
