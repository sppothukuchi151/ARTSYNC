// This is ArtSync's signature visual element - the folded/origami-style
// geometric shapes seen in the corners of the mockups. It's a decorative
// SVG, purely visual (aria-hidden), reused across pages so it becomes a
// recognizable part of the brand rather than a one-off illustration.
//
// "corner" controls which corner it's anchored to and flips the shape
// accordingly, so the same component works in all four corners.
const FoldedCorner = ({ corner = "top-left", className = "" }) => {
  const positionClasses = {
    "top-left": "top-0 left-0",
    "top-right": "top-0 right-0 scale-x-[-1]",
    "bottom-left": "bottom-0 left-0 scale-y-[-1]",
    "bottom-right": "bottom-0 right-0 scale-x-[-1] scale-y-[-1]",
  };

  return (
    <div
      aria-hidden="true"
      className={`absolute pointer-events-none animate-unfold ${positionClasses[corner]} ${className}`}
      style={{ animationDelay: "0.1s" }}
    >
      <svg width="180" height="180" viewBox="0 0 180 180" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 0H140L60 60H0V0Z" fill="#2E1065" />
        <path d="M20 20H120L70 70H20V20Z" fill="#C4B5FD" />
        <path d="M0 60H60L0 120V60Z" fill="#6A0DAD" />
        <path d="M0 130H50L20 165H0V130Z" fill="#E9D5FF" />
      </svg>
    </div>
  );
};

export default FoldedCorner;
