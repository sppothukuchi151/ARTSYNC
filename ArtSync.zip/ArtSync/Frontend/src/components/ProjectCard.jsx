import { Link } from "react-router-dom";

const categoryDot = {
  Music: "bg-pink-400",
  Design: "bg-primary",
  Writing: "bg-amber-400",
  Photography: "bg-teal-400",
  Filmmaking: "bg-orange-400",
  Illustration: "bg-indigo",
  Other: "bg-gray-400",
};

const ProjectCard = ({ project }) => {
  return (
    <Link
      to={`/projects/${project._id}`}
      className="group flex items-center justify-between gap-4 bg-white hover:bg-card rounded-2xl px-5 py-4 shadow-card hover:shadow-soft hover:-translate-y-0.5 transition-all duration-200"
    >
      <div className="min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className={`w-1.5 h-1.5 rounded-full ${categoryDot[project.category] || categoryDot.Other}`} />
          <span className="text-xs font-medium text-ink/50 uppercase tracking-wide">
            {project.category}
          </span>
        </div>
        <h3 className="font-display font-semibold text-lg text-ink truncate">
          {project.title}
        </h3>
        <p className="text-sm text-ink/60 truncate mt-0.5">
          {project.requiredSkills?.slice(0, 3).join(" · ") || "No skills listed"}
        </p>
      </div>

      <svg
        className="w-5 h-5 text-ink/30 group-hover:text-primary group-hover:translate-x-0.5 transition-all flex-shrink-0"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        aria-hidden="true"
      >
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      </svg>
    </Link>
  );
};

export default ProjectCard;
