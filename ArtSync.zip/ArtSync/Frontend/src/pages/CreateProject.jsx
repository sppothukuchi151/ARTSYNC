import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

const categories = ["Music", "Design", "Writing", "Photography", "Filmmaking", "Illustration", "Other"];

const CreateProject = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: "",
    description: "",
    requiredSkills: "",
    deadline: "",
    collaboratorsNeeded: 1,
    category: "Design",
  });
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const payload = {
        ...form,
        // The backend expects an array here - split the comma-separated
        // input into a clean list of skills
        requiredSkills: form.requiredSkills
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        collaboratorsNeeded: Number(form.collaboratorsNeeded) || 1,
      };

      const res = await api.post("/projects", payload);
      navigate(`/projects/${res.data._id}`);
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-xl mx-auto px-6 py-10 animate-floatUp">
        <h1 className="font-display font-semibold text-3xl text-ink mb-1">Post a project</h1>
        <p className="text-ink/60 mb-8">Describe what you're building and who you need.</p>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-ink mb-1.5">
              Project name
            </label>
            <input
              id="title"
              name="title"
              type="text"
              required
              value={form.title}
              onChange={handleChange}
              placeholder="e.g. Need a UI Designer for a Mental Health App"
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
            />
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-ink mb-1.5">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              required
              rows={4}
              value={form.description}
              onChange={handleChange}
              placeholder="What are you building, and what kind of help do you need?"
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors resize-none"
            />
          </div>

          <div>
            <label htmlFor="requiredSkills" className="block text-sm font-medium text-ink mb-1.5">
              Required skills
            </label>
            <input
              id="requiredSkills"
              name="requiredSkills"
              type="text"
              value={form.requiredSkills}
              onChange={handleChange}
              placeholder="React, Figma, Illustration (comma-separated)"
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-ink mb-1.5">
                Category
              </label>
              <select
                id="category"
                name="category"
                value={form.category}
                onChange={handleChange}
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink focus:border-primary outline-none transition-colors"
              >
                {categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="collaboratorsNeeded" className="block text-sm font-medium text-ink mb-1.5">
                Collaborators needed
              </label>
              <input
                id="collaboratorsNeeded"
                name="collaboratorsNeeded"
                type="number"
                min={1}
                value={form.collaboratorsNeeded}
                onChange={handleChange}
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink focus:border-primary outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label htmlFor="deadline" className="block text-sm font-medium text-ink mb-1.5">
              Deadline (optional)
            </label>
            <input
              id="deadline"
              name="deadline"
              type="date"
              value={form.deadline}
              onChange={handleChange}
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink focus:border-primary outline-none transition-colors"
            />
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl py-3 disabled:opacity-60"
          >
            {submitting ? "Posting..." : "Post project"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateProject;
