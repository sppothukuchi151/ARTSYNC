import { useState, useEffect, useCallback } from "react";
import api from "../api/axios";
import Navbar from "../components/Navbar";
import ProjectCard from "../components/ProjectCard";

const categories = ["All", "Music", "Design", "Writing", "Photography", "Filmmaking", "Illustration", "Other"];

const Browse = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");

  const fetchProjects = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (search.trim()) params.search = search.trim();
      if (category !== "All") params.category = category;

      const res = await api.get("/projects", { params });
      setProjects(res.data);
    } catch (err) {
      console.error("Failed to load projects", err);
    } finally {
      setLoading(false);
    }
  }, [search, category]);

  // Refetch whenever the search text or category changes, with a short
  // debounce on typing so we're not hitting the API on every keystroke
  useEffect(() => {
    const timeout = setTimeout(fetchProjects, 300);
    return () => clearTimeout(timeout);
  }, [fetchProjects]);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-3xl mx-auto px-6 py-10">
        <div className="mb-8 animate-floatUp">
          <h1 className="font-display font-semibold text-3xl text-ink mb-1">Browse Projects</h1>
          <p className="text-ink/60">Find a creative project that needs your skills.</p>
        </div>

        {/* Search + filter controls */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <svg
              className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-ink/40"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z"
              />
            </svg>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by keyword..."
              className="w-full rounded-xl border border-violet/30 bg-white pl-10 pr-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
            />
          </div>

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink focus:border-primary outline-none transition-colors"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        {/* Results */}
        {loading ? (
          <p className="text-ink/50 text-center py-12">Loading projects...</p>
        ) : projects.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl">
            <p className="font-display font-semibold text-lg text-ink mb-1">No projects found</p>
            <p className="text-ink/60 text-sm">
              Try a different search term or category — or be the first to post one.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {projects.map((project, i) => (
              <div key={project._id} className="animate-floatUp" style={{ animationDelay: `${i * 40}ms` }}>
                <ProjectCard project={project} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Browse;
