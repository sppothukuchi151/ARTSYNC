import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

const statusStyles = {
  pending: "bg-amber-50 text-amber-700",
  accepted: "bg-green-50 text-green-700",
  rejected: "bg-red-50 text-red-600",
};

const ProjectRequests = () => {
  const { id } = useParams();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [respondingId, setRespondingId] = useState(null);

  const loadRequests = () => {
    api
      .get(`/requests/project/${id}`)
      .then((res) => setRequests(res.data))
      .catch((err) => console.error("Failed to load requests", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadRequests();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const respond = async (requestId, status) => {
    setRespondingId(requestId);
    try {
      await api.put(`/requests/${requestId}`, { status });
      setRequests((prev) => prev.map((r) => (r._id === requestId ? { ...r, status } : r)));
    } catch (err) {
      console.error("Failed to respond to request", err);
    } finally {
      setRespondingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-2xl mx-auto px-6 py-10 animate-floatUp">
        <Link to={`/projects/${id}`} className="text-sm text-primary hover:underline mb-4 inline-block">
          ← Back to project
        </Link>
        <h1 className="font-display font-semibold text-3xl text-ink mb-1">Join requests</h1>
        <p className="text-ink/60 mb-8">People who want to collaborate on this project.</p>

        {loading ? (
          <p className="text-ink/50 text-center py-12">Loading requests...</p>
        ) : requests.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl">
            <p className="font-display font-semibold text-lg text-ink mb-1">No requests yet</p>
            <p className="text-ink/60 text-sm">Once someone requests to join, they'll show up here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((req) => (
              <div key={req._id} className="bg-card rounded-2xl p-5">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <p className="font-display font-semibold text-ink">{req.applicant?.name}</p>
                    {req.applicant?.skills?.length > 0 && (
                      <p className="text-sm text-ink/60 mt-0.5">{req.applicant.skills.join(" · ")}</p>
                    )}
                  </div>
                  <span className={`text-xs font-medium rounded-full px-2.5 py-1 capitalize ${statusStyles[req.status]}`}>
                    {req.status}
                  </span>
                </div>

                {req.message && <p className="text-ink/80 text-sm mb-4">{req.message}</p>}

                {req.status === "pending" && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => respond(req._id, "accepted")}
                      disabled={respondingId === req._id}
                      className="flex-1 bg-primary hover:bg-indigo transition-colors text-white text-sm font-medium rounded-lg py-2 disabled:opacity-60"
                    >
                      Accept
                    </button>
                    <button
                      onClick={() => respond(req._id, "rejected")}
                      disabled={respondingId === req._id}
                      className="flex-1 bg-white hover:bg-red-50 border border-red-200 transition-colors text-red-600 text-sm font-medium rounded-lg py-2 disabled:opacity-60"
                    >
                      Reject
                    </button>
                  </div>
                )}

                {req.status === "accepted" && (
                  <Link
                    to={`/chat/${id}/${req.applicant._id}`}
                    className="block text-center bg-lavender/50 hover:bg-lavender transition-colors text-primary text-sm font-medium rounded-lg py-2"
                  >
                    💬 Message {req.applicant?.name?.split(" ")[0]}
                  </Link>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectRequests;
