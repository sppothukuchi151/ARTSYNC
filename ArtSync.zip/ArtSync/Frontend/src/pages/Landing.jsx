import { Link } from "react-router-dom";
import FoldedCorner from "../components/FoldedCorner";

const Landing = () => {
  return (
    <div className="relative min-h-screen bg-white overflow-hidden flex flex-col items-center justify-center px-6 text-center">
      <FoldedCorner corner="top-left" />
      <FoldedCorner corner="bottom-right" />

      <div className="relative z-10 max-w-2xl animate-floatUp">
        <h1 className="font-display font-bold text-5xl sm:text-6xl text-indigo mb-4">
          ArtSync
        </h1>
        <p className="text-lg text-ink/70 mb-10 max-w-lg mx-auto">
          Find collaborators for the project you're building, not just people
          browsing portfolios. For musicians, designers, writers,
          photographers, filmmakers, and illustrators.
        </p>

        <div className="flex items-center justify-center gap-4">
          <Link
            to="/signup"
            className="bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl px-6 py-3"
          >
            Get started
          </Link>
          <Link
            to="/login"
            className="bg-lavender/50 hover:bg-lavender transition-colors text-primary font-medium rounded-xl px-6 py-3"
          >
            Log in
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Landing;
