import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api/axios";
import { connectSocket, disconnectSocket } from "../api/socket";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";

const Chat = () => {
  const { projectId, otherUserId } = useParams();
  const { user } = useAuth();

  const [messages, setMessages] = useState([]);
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [otherUserName, setOtherUserName] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    api
      .get(`/messages/${projectId}/${otherUserId}`)
      .then((res) => setMessages(res.data))
      .catch(() =>
        setError("You can only chat after a request has been accepted for this project.")
      )
      .finally(() => setLoading(false));

    api
      .get(`/users/${otherUserId}`)
      .then((res) => setOtherUserName(res.data.name))
      .catch(() => setOtherUserName("Collaborator"));
  }, [projectId, otherUserId]);

  useEffect(() => {
    const socket = connectSocket();

    const handleIncoming = (message) => {
      const belongsHere =
        message.project === projectId &&
        ((message.sender === user._id && message.recipient === otherUserId) ||
          (message.sender === otherUserId && message.recipient === user._id));

      if (belongsHere) {
        setMessages((prev) => [...prev, message]);
      }
    };

    socket.on("receiveMessage", handleIncoming);
    socket.on("errorMessage", (err) => setError(err.message));

    return () => {
      socket.off("receiveMessage", handleIncoming);
      socket.off("errorMessage");
    };
  }, [projectId, otherUserId, user._id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    return () => disconnectSocket();
  }, []);

  const handleSend = (e) => {
    e.preventDefault();
    if (!content.trim()) return;

    const socket = connectSocket();
    socket.emit("sendMessage", {
      projectId,
      recipientId: otherUserId,
      content: content.trim(),
    });
    setContent("");
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Navbar />

      <div className="max-w-2xl w-full mx-auto flex flex-col flex-1 px-6 py-6">
        <Link to={`/projects/${projectId}`} className="text-sm text-primary hover:underline mb-4 inline-block">
          ← Back to project
        </Link>

        <h1 className="font-display font-semibold text-2xl text-ink mb-4">
          Chat with {otherUserName}
        </h1>

        {error ? (
          <div className="bg-card rounded-2xl p-8 text-center flex-1 flex flex-col justify-center">
            <p className="text-ink/70">{error}</p>
          </div>
        ) : (
          <>
            <div className="flex-1 bg-card rounded-2xl p-5 overflow-y-auto min-h-[400px] max-h-[500px] flex flex-col gap-3">
              {loading ? (
                <p className="text-ink/50 text-center m-auto">Loading messages...</p>
              ) : messages.length === 0 ? (
                <p className="text-ink/50 text-center m-auto">
                  No messages yet — say hello to start the conversation!
                </p>
              ) : (
                messages.map((msg) => {
                  const isMine = msg.sender === user._id;
                  return (
                    <div key={msg._id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${
                          isMine
                            ? "bg-primary text-white rounded-br-sm"
                            : "bg-white text-ink rounded-bl-sm shadow-card"
                        }`}
                      >
                        {msg.content}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={bottomRef} />
            </div>

            <form onSubmit={handleSend} className="flex gap-2 mt-4">
              <input
                type="text"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
              />
              <button
                type="submit"
                className="bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl px-6"
              >
                Send
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default Chat;
