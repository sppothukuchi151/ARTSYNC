import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

const typeIcons = {
  new_request: "👋",
  request_accepted: "✅",
  request_rejected: "✕",
  new_message: "💬",
};

const timeAgo = (date) => {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadNotifications = () => {
    api
      .get("/notifications")
      .then((res) => setNotifications(res.data))
      .catch((err) => console.error("Failed to load notifications", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadNotifications();
  }, []);

  const markAsRead = async (notifId) => {
    try {
      await api.put(`/notifications/${notifId}/read`);
      setNotifications((prev) => prev.map((n) => (n._id === notifId ? { ...n, isRead: true } : n)));
    } catch (err) {
      console.error("Failed to mark as read", err);
    }
  };

  const markAllRead = async () => {
    try {
      await api.put("/notifications/read-all");
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (err) {
      console.error("Failed to mark all as read", err);
    }
  };

  const hasUnread = notifications.some((n) => !n.isRead);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-2xl mx-auto px-6 py-10 animate-floatUp">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display font-semibold text-3xl text-ink mb-1">Notifications</h1>
            <p className="text-ink/60">Stay on top of your collaborations.</p>
          </div>
          {hasUnread && (
            <button onClick={markAllRead} className="text-sm text-primary font-medium hover:underline whitespace-nowrap">
              Mark all read
            </button>
          )}
        </div>

        {loading ? (
          <p className="text-ink/50 text-center py-12">Loading...</p>
        ) : notifications.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl">
            <p className="font-display font-semibold text-lg text-ink mb-1">No notifications yet</p>
            <p className="text-ink/60 text-sm">You'll see updates here about requests, messages, and more.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {notifications.map((notif) => (
              <div
                key={notif._id}
                onClick={() => !notif.isRead && markAsRead(notif._id)}
                className={`flex items-start gap-3 rounded-2xl p-4 cursor-pointer transition-colors ${
                  notif.isRead ? "bg-white" : "bg-lavender/30 hover:bg-lavender/50"
                }`}
              >
                <span className="text-xl flex-shrink-0">{typeIcons[notif.type] || "🔔"}</span>
                <div className="min-w-0">
                  <p className={`text-sm ${notif.isRead ? "text-ink/70" : "text-ink font-medium"}`}>
                    {notif.message}
                  </p>
                  <p className="text-xs text-ink/40 mt-1">{timeAgo(notif.createdAt)}</p>
                </div>
                {!notif.isRead && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5 ml-auto" />}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
