import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import FoldedCorner from "../components/FoldedCorner";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    try {
      const res = await api.post("/auth/login", { email, password });
      login(res.data);
      navigate("/browse");
    } catch (err) {
      setError(err.response?.data?.message || "Something went wrong. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-white overflow-hidden flex items-center justify-center px-6">
      <FoldedCorner corner="top-left" />
      <FoldedCorner corner="bottom-right" />

      <div className="relative z-10 w-full max-w-md animate-floatUp">
        <Link to="/" className="block text-center mb-8">
          <span className="font-display font-bold text-2xl text-indigo">ArtSync</span>
        </Link>

        <div className="bg-lavender/40 rounded-3xl p-8 shadow-soft">
          <h1 className="font-display font-semibold text-3xl text-ink text-center mb-6">
            Welcome back
          </h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-ink mb-1.5">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-ink mb-1.5">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl py-2.5 mt-2 disabled:opacity-60"
            >
              {submitting ? "Logging in..." : "Log in"}
            </button>
          </form>

          <p className="text-center text-sm text-ink/70 mt-6">
            New to ArtSync?{" "}
            <Link to="/signup" className="text-primary font-medium hover:underline">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
