import { useState, useEffect } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";

const Profile = () => {
  const { setUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [form, setForm] = useState({
    bio: "",
    skills: "",
    experience: "",
    location: "",
    behance: "",
    github: "",
    instagram: "",
    website: "",
  });

  useEffect(() => {
    api.get("/users/me").then((res) => {
      const data = res.data;
      setProfile(data);
      setForm({
        bio: data.bio || "",
        skills: (data.skills || []).join(", "),
        experience: data.experience || "",
        location: data.location || "",
        behance: data.portfolioLinks?.behance || "",
        github: data.portfolioLinks?.github || "",
        instagram: data.portfolioLinks?.instagram || "",
        website: data.portfolioLinks?.website || "",
      });
      setLoading(false);
    });
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setSaved(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await api.put("/users/me", {
        bio: form.bio,
        skills: form.skills.split(",").map((s) => s.trim()).filter(Boolean),
        experience: form.experience,
        location: form.location,
        portfolioLinks: {
          behance: form.behance,
          github: form.github,
          instagram: form.instagram,
          website: form.website,
        },
      });
      setProfile(res.data);
      setUser((prev) => ({ ...prev, name: res.data.name })); // keep navbar name in sync
      setSaved(true);
    } catch (err) {
      console.error("Failed to save profile", err);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Navbar />
        <p className="text-center text-ink/50 py-16">Loading profile...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-xl mx-auto px-6 py-10 animate-floatUp">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 rounded-full bg-lavender flex items-center justify-center font-display font-semibold text-2xl text-primary flex-shrink-0">
            {profile.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <h1 className="font-display font-semibold text-2xl text-ink">{profile.name}</h1>
            <p className="text-ink/60 text-sm">{profile.email}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="bio" className="block text-sm font-medium text-ink mb-1.5">
              Bio
            </label>
            <textarea
              id="bio"
              name="bio"
              rows={3}
              value={form.bio}
              onChange={handleChange}
              placeholder="Tell people what you do and what you're into..."
              maxLength={500}
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors resize-none"
            />
          </div>

          <div>
            <label htmlFor="skills" className="block text-sm font-medium text-ink mb-1.5">
              Skills
            </label>
            <input
              id="skills"
              name="skills"
              type="text"
              value={form.skills}
              onChange={handleChange}
              placeholder="UI Design, React, Illustration (comma-separated)"
              className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="experience" className="block text-sm font-medium text-ink mb-1.5">
                Experience
              </label>
              <input
                id="experience"
                name="experience"
                type="text"
                value={form.experience}
                onChange={handleChange}
                placeholder="e.g. 2 years"
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
              />
            </div>
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-ink mb-1.5">
                Location
              </label>
              <input
                id="location"
                name="location"
                type="text"
                value={form.location}
                onChange={handleChange}
                placeholder="City, Country"
                className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <p className="text-sm font-medium text-ink mb-2">Portfolio links</p>
            <div className="space-y-2">
              {["behance", "github", "instagram", "website"].map((field) => (
                <input
                  key={field}
                  name={field}
                  type="text"
                  value={form[field]}
                  onChange={handleChange}
                  placeholder={`${field.charAt(0).toUpperCase() + field.slice(1)} URL`}
                  className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-sm text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors"
                />
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl py-3 disabled:opacity-60"
          >
            {saving ? "Saving..." : saved ? "Saved ✓" : "Save profile"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
