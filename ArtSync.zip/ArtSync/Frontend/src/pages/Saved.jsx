import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";
import ProjectCard from "../components/ProjectCard";

const Saved = () => {
  const [saved, setSaved] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/saved")
      .then((res) => setSaved(res.data))
      .catch((err) => console.error("Failed to load saved projects", err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-2xl mx-auto px-6 py-10 animate-floatUp">
        <h1 className="font-display font-semibold text-3xl text-ink mb-1">Saved projects</h1>
        <p className="text-ink/60 mb-8">Projects you've bookmarked to revisit later.</p>

        {loading ? (
          <p className="text-ink/50 text-center py-12">Loading...</p>
        ) : saved.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl">
            <p className="font-display font-semibold text-lg text-ink mb-1">Nothing saved yet</p>
            <p className="text-ink/60 text-sm mb-4">Tap "Save for later" on a project to bookmark it here.</p>
            <Link to="/browse" className="text-primary font-medium hover:underline">
              Browse projects
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {saved.map((item) => (
              <ProjectCard key={item._id} project={item.project} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Saved;
