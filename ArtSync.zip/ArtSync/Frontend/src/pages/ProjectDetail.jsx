import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import Navbar from "../components/Navbar";

const ProjectDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [requestStatus, setRequestStatus] = useState(null); // null | "sending" | "sent" | "error"
  const [requestError, setRequestError] = useState("");
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    api
      .get(`/projects/${id}`)
      .then((res) => setProject(res.data))
      .catch(() => setProject(null))
      .finally(() => setLoading(false));
  }, [id]);

  const isOwner = project && user && project.owner._id === user._id;

  const handleRequestToJoin = async (e) => {
    e.preventDefault();
    setRequestStatus("sending");
    setRequestError("");
    try {
      await api.post("/requests", { projectId: id, message });
      setRequestStatus("sent");
    } catch (err) {
      setRequestStatus("error");
      setRequestError(err.response?.data?.message || "Could not send request");
    }
  };

  const handleSaveToggle = async () => {
    try {
      if (isSaved) {
        await api.delete(`/saved/${id}`);
        setIsSaved(false);
      } else {
        await api.post(`/saved/${id}`);
        setIsSaved(true);
      }
    } catch (err) {
      console.error("Failed to toggle save", err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Navbar />
        <p className="text-center text-ink/50 py-16">Loading project...</p>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-white">
        <Navbar />
        <div className="max-w-2xl mx-auto px-6 py-16 text-center">
          <p className="font-display font-semibold text-xl text-ink mb-2">Project not found</p>
          <button onClick={() => navigate("/browse")} className="text-primary font-medium hover:underline">
            Back to Browse
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-2xl mx-auto px-6 py-10 animate-floatUp">
        {/* Header */}
        <div className="mb-6">
          <span className="text-xs font-medium text-primary uppercase tracking-wide bg-lavender/50 rounded-full px-3 py-1">
            {project.category}
          </span>
          <h1 className="font-display font-semibold text-3xl text-ink mt-3 mb-2">{project.title}</h1>
          <p className="text-sm text-ink/60">
            Posted by <span className="font-medium text-ink">{project.owner.name}</span>
            {project.status === "closed" && (
              <span className="ml-2 text-red-500 font-medium">· Closed</span>
            )}
          </p>
        </div>

        {/* Description */}
        <div className="bg-card rounded-2xl p-6 mb-4">
          <h2 className="font-display font-semibold text-ink mb-2">About this project</h2>
          <p className="text-ink/80 whitespace-pre-line">{project.description}</p>
        </div>

        {/* Details grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-card rounded-2xl p-5">
            <p className="text-xs font-medium text-ink/50 uppercase tracking-wide mb-2">Skills needed</p>
            <div className="flex flex-wrap gap-1.5">
              {project.requiredSkills?.length ? (
                project.requiredSkills.map((skill) => (
                  <span key={skill} className="text-xs bg-lavender/60 text-primary font-medium rounded-full px-2.5 py-1">
                    {skill}
                  </span>
                ))
              ) : (
                <span className="text-sm text-ink/40">None listed</span>
              )}
            </div>
          </div>

          <div className="bg-card rounded-2xl p-5">
            <p className="text-xs font-medium text-ink/50 uppercase tracking-wide mb-2">Collaborators needed</p>
            <p className="text-ink font-medium">{project.collaboratorsNeeded}</p>
          </div>

          {project.deadline && (
            <div className="bg-card rounded-2xl p-5 col-span-2">
              <p className="text-xs font-medium text-ink/50 uppercase tracking-wide mb-2">Deadline</p>
              <p className="text-ink font-medium">
                {new Date(project.deadline).toLocaleDateString(undefined, {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
          )}
        </div>

        {/* Actions */}
        {isOwner ? (
          <button
            onClick={() => navigate(`/projects/${id}/requests`)}
            className="w-full bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl py-3"
          >
            View requests for this project
          </button>
        ) : (
          <div className="space-y-3">
            {requestStatus === "sent" ? (
              <p className="bg-green-50 text-green-700 text-sm font-medium rounded-xl px-4 py-3 text-center">
                Request sent! The project owner will review it soon.
              </p>
            ) : (
              <form onSubmit={handleRequestToJoin} className="space-y-3">
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell them why you'd be a good fit..."
                  rows={3}
                  className="w-full rounded-xl border border-violet/30 bg-white px-4 py-2.5 text-ink placeholder:text-ink/40 focus:border-primary outline-none transition-colors resize-none"
                />
                {requestStatus === "error" && (
                  <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{requestError}</p>
                )}
                <button
                  type="submit"
                  disabled={requestStatus === "sending"}
                  className="w-full bg-primary hover:bg-indigo transition-colors text-white font-medium rounded-xl py-3 disabled:opacity-60"
                >
                  {requestStatus === "sending" ? "Sending..." : "Request to join"}
                </button>
              </form>
            )}

            <button
              onClick={handleSaveToggle}
              className="w-full bg-lavender/40 hover:bg-lavender/70 transition-colors text-primary font-medium rounded-xl py-3"
            >
              {isSaved ? "★ Saved" : "☆ Save for later"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectDetail;
