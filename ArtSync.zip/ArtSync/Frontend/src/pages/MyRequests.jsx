import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

const statusStyles = {
  pending: "bg-amber-50 text-amber-700",
  accepted: "bg-green-50 text-green-700",
  rejected: "bg-red-50 text-red-600",
};

const MyRequests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/requests/my")
      .then((res) => setRequests(res.data))
      .catch((err) => console.error("Failed to load requests", err))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-2xl mx-auto px-6 py-10 animate-floatUp">
        <h1 className="font-display font-semibold text-3xl text-ink mb-1">My requests</h1>
        <p className="text-ink/60 mb-8">Projects you've asked to join.</p>

        {loading ? (
          <p className="text-ink/50 text-center py-12">Loading...</p>
        ) : requests.length === 0 ? (
          <div className="text-center py-16 bg-card rounded-2xl">
            <p className="font-display font-semibold text-lg text-ink mb-1">No requests sent yet</p>
            <p className="text-ink/60 text-sm mb-4">Browse projects and request to join one that fits your skills.</p>
            <Link to="/browse" className="text-primary font-medium hover:underline">
              Browse projects
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((req) => (
              <div key={req._id} className="bg-card rounded-2xl p-5">
                <Link to={`/projects/${req.project?._id}`} className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-display font-semibold text-ink">{req.project?.title}</p>
                    <p className="text-sm text-ink/60 mt-0.5">{req.project?.category}</p>
                  </div>
                  <span className={`text-xs font-medium rounded-full px-2.5 py-1 capitalize flex-shrink-0 ${statusStyles[req.status]}`}>
                    {req.status}
                  </span>
                </Link>

                {req.status === "accepted" && req.project?.owner && (
                  <Link
                    to={`/chat/${req.project._id}/${req.project.owner._id}`}
                    className="block text-center bg-lavender/50 hover:bg-lavender transition-colors text-primary text-sm font-medium rounded-lg py-2 mt-3"
                  >
                    💬 Message {req.project.owner.name?.split(" ")[0]}
                  </Link>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyRequests;
