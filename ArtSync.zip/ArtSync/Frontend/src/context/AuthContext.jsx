import { createContext, useContext, useState, useEffect } from "react";
import api from "../api/axios";

const AuthContext = createContext(null);

// Wrap the whole app in this (see main.jsx) so any component can access
// "who's logged in" via the useAuth() hook below, instead of passing
// user data down through props manually at every level.
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // On first load, check if we have a saved token and, if so, fetch
  // the matching profile - this is what keeps you "logged in" after
  // refreshing the page.
  useEffect(() => {
    const token = localStorage.getItem("artsync_token");
    if (!token) {
      setLoading(false);
      return;
    }

    api
      .get("/users/me")
      .then((res) => setUser(res.data))
      .catch(() => {
        // Token was invalid/expired - clear it out
        localStorage.removeItem("artsync_token");
      })
      .finally(() => setLoading(false));
  }, []);

  const login = (userData) => {
    localStorage.setItem("artsync_token", userData.token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem("artsync_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook - lets any component just do "const { user } = useAuth()"
export const useAuth = () => useContext(AuthContext);
