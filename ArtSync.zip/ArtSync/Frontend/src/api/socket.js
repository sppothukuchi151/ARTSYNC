import { io } from "socket.io-client";

let socket = null;

// We create ONE socket connection and reuse it everywhere, rather than
// opening a new connection every time a component mounts. Call this once
// when the Chat page loads.
export const connectSocket = () => {
  if (socket?.connected) return socket;

  const token = localStorage.getItem("artsync_token");

  socket = io("http://localhost:5000", {
    auth: { token }, // read by the server-side auth middleware in utils/socket.js
  });

  return socket;
};

export const getSocket = () => socket;

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
