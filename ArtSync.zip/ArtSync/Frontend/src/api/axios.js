import axios from "axios";

// All backend requests go through this instance so we don't repeat
// the base URL or auth header logic in every single component.
const api = axios.create({
  baseURL: "http://localhost:5000/api",
});

// Before every request, check if we have a saved token and attach it.
// This is what lets protected routes (like GET /users/me) work.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("artsync_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
